#ifndef __VM_INIT
#define __VM_INIT

#include <GL/glut.h>    // Header File For The GLUT Library 
#include <GL/gl.h>	// Header File For The OpenGL32 Library


void VM_init();
#endif
