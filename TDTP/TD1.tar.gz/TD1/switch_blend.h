#ifndef __SWITCH_BLEND
#define __SWITCH_BLEND
#include <GL/gl.h>	// Header File For The OpenGL32 Library

GLuint switch_blend(GLuint);
#endif
