#ifndef __SWITCH_LIGHT
#define __SWITCH_LIGHT

#include <GL/gl.h>	// Header File For The OpenGL32 Library

GLuint switch_light(GLuint);
#endif
