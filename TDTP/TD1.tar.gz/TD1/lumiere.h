#ifndef __LUMIERE
#define __LUMIERE

#include <GL/gl.h>	// Header File For The OpenGL32 Library

void lumiere();
#endif
