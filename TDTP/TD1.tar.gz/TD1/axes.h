#ifndef __AXES
#define __AXES

#include <GL/gl.h>	// Header File For The OpenGL32 Library

void axes(void);
#endif
